<?php

namespace AppBundle\Entity;

/**
 * Lanzamiento
 */
class Lanzamiento
{
    /**
     * @var string
     */
    private $consola;

    /**
     * @var string
     */
    private $juego;

    /**
     * @var integer
     */
    private $numero;


    /**
     * Set consola
     *
     * @param string $consola
     *
     * @return Lanzamiento
     */
    public function setConsola($consola)
    {
        $this->consola = $consola;

        return $this;
    }

    /**
     * Get consola
     *
     * @return string
     */
    public function getConsola()
    {
        return $this->consola;
    }

    /**
     * Set juego
     *
     * @param string $juego
     *
     * @return Lanzamiento
     */
    public function setJuego($juego)
    {
        $this->juego = $juego;

        return $this;
    }

    /**
     * Get juego
     *
     * @return string
     */
    public function getJuego()
    {
        return $this->juego;
    }

    /**
     * Get numero
     *
     * @return integer
     */
    public function getNumero()
    {
        return $this->numero;
    }
}

