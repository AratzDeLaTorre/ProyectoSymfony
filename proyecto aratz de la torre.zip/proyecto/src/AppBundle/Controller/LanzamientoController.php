<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Lanzamiento;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;use Symfony\Component\HttpFoundation\Request;

/**
 * Lanzamiento controller.
 *
 * @Route("lanzamiento")
 */
class LanzamientoController extends Controller
{
    /**
     * Lists all lanzamiento entities.
     *
     * @Route("/", name="lanzamiento_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();
        $lanzamientos = $em->getRepository('AppBundle:Lanzamiento')->findAll();

        return $this->render('lanzamiento/index.html.twig', array(
            'lanzamientos' => $lanzamientos,
        ));
    }
    
        /**
     * Lists all lanzamiento entities.
     *
     * @Route("/pc", name="pc")
     * @Method("GET")
     */
    public function pcAction()
    {
        $em = $this->getDoctrine()->getManager();
        $criterio['consola']='pc';
        $lanzamientos = $em->getRepository('AppBundle:Lanzamiento')->findBy($criterio);

        return $this->render('lanzamiento/index.html.twig', array(
            'lanzamientos' => $lanzamientos,
        ));
    }
    
            /**
     * Lists all lanzamiento entities.
     *
     * @Route("/xbox", name="xbox")
     * @Method("GET")
     */
    public function xboxAction()
    {
        $em = $this->getDoctrine()->getManager();
        $criterio['consola']='xbox';
        $lanzamientos = $em->getRepository('AppBundle:Lanzamiento')->findBy($criterio);

        return $this->render('lanzamiento/index.html.twig', array(
            'lanzamientos' => $lanzamientos,
        ));
    }
    
                /**
     * Lists all lanzamiento entities.
     *
     * @Route("/ps4", name="ps4")
     * @Method("GET")
     */
    public function ps4Action()
    {
        $em = $this->getDoctrine()->getManager();
        $criterio['consola']='ps4';
        $lanzamientos = $em->getRepository('AppBundle:Lanzamiento')->findBy($criterio);

        return $this->render('lanzamiento/index.html.twig', array(
            'lanzamientos' => $lanzamientos,
        ));
    }
    

    

    
    

    /**
     * Creates a new lanzamiento entity.
     *
     * @Route("/new", name="lanzamiento_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
        $lanzamiento = new Lanzamiento();
        $form = $this->createForm('AppBundle\Form\LanzamientoType', $lanzamiento);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($lanzamiento);
            $em->flush();

            return $this->redirectToRoute('lanzamiento_show', array('numero' => $lanzamiento->getNumero()));
        }

        return $this->render('lanzamiento/new.html.twig', array(
            'lanzamiento' => $lanzamiento,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a lanzamiento entity.
     *
     * @Route("/{numero}", name="lanzamiento_show")
     * @Method("GET")
     */
    public function showAction(Lanzamiento $lanzamiento)
    {
        $deleteForm = $this->createDeleteForm($lanzamiento);

        return $this->render('lanzamiento/show.html.twig', array(
            'lanzamiento' => $lanzamiento,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing lanzamiento entity.
     *
     * @Route("/{numero}/edit", name="lanzamiento_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, Lanzamiento $lanzamiento)
    {
        $deleteForm = $this->createDeleteForm($lanzamiento);
        $editForm = $this->createForm('AppBundle\Form\LanzamientoType', $lanzamiento);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('lanzamiento_edit', array('numero' => $lanzamiento->getNumero()));
        }

        return $this->render('lanzamiento/edit.html.twig', array(
            'lanzamiento' => $lanzamiento,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a lanzamiento entity.
     *
     * @Route("/{numero}", name="lanzamiento_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Lanzamiento $lanzamiento)
    {
        $form = $this->createDeleteForm($lanzamiento);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($lanzamiento);
            $em->flush();
        }

        return $this->redirectToRoute('lanzamiento_index');
    }

    /**
     * Creates a form to delete a lanzamiento entity.
     *
     * @param Lanzamiento $lanzamiento The lanzamiento entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Lanzamiento $lanzamiento)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('lanzamiento_delete', array('numero' => $lanzamiento->getNumero())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
