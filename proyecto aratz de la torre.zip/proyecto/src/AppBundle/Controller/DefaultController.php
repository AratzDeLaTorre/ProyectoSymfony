<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="inicio")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
    
       
   
    /**
     * @Route("/mielda", name="mielda")
     */
    public function AAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/mielda.html.twig');
    }
    
     /**
     * @Route("/nintendo", name="nintendo")
     */
    public function BAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/nintendo.html.twig');
    }
         /**
     * @Route("/sony", name="sony")
     */
    public function CAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/sony.html.twig');
    }
         /**
     * @Route("/microsoft", name="microsoft")
     */
    public function DAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/microsoft.html.twig');
    }
 
}
